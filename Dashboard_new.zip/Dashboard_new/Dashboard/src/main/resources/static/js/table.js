/**
 * 
 */
$(document).ready(function(){
	alert(1);
	$.ajax({                                                                   
	    type: "POST",
        contentType : "application/json",
	    url: "/api/comp",
	    data: {"success" : "OK"},
	    success: function(response) {
	    	alert('sucess');
	    },
	    error: function(e) {
	        alert("Error while saving filters: " + e.message);
	    }
	});
}