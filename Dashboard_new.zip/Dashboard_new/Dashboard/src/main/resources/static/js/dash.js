/**
 * 
 */

$(document).ready(function(){
	
	call_ajax();
	
	window.setInterval(function(){
		  /// call your function here
		call_ajax();
		}, 10000);
	
	function call_ajax(){
	$.ajax({                                                                   
	    type: "GET",
        //contentType : "application/json",
        cache: false,
	    url: "/api/reports",
	    data: {"success" : "OK"},
	    success: function(result) {
	    	show_dash(result);
	    	
	    },
	    error: function(e) {
	        alert("Error while saving filters: " + e.message);
	    }
	})
	$.ajax({                                                                   
	    type: "GET",
        //contentType : "application/json",
	    url: "/api/comp",
	    data: {"success" : "OK"},
	    success: function(data) {
	    	show_components(data);
	    },
	    error: function(e) {
	        alert("Error while saving filters: " + e.message);
	    }
	})
	}
	
	function show_dash(response) {
		var ord = null;
    	var order_Type = null;
    	var totalOrderCount = null;
    	ord = response[0];
    	order_Type = response[1];
    	totalOrderCount = response[2];
    	var data = {
	            labels: ['S_ESCL', 'S_SRM', 'Pend-Open Order', 'Pending Asset', 'Open Payment'],//['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
	            series: [
	                ord
	            ]
	        };
	
	        var options = {
	            seriesBarDistance: 10,
	            axisX: {
	                showGrid: false
	            },
	            height: "245px"
	        };
	
	        var responsiveOptions = [
	            ['screen and (max-width: 640px)', {
	                seriesBarDistance: 5,
	                axisX: {
	                    labelInterpolationFnc: function(value) {
	                        return value[0];
	                    }
	                }
	            }]
	        ];
	
	        var chartActivity = Chartist.Bar('#chartActivity', data, options, responsiveOptions);
	        
	        var ord_data = {
		            labels: order_Type.orderType,
		            series: [order_Type.orderCount]				            
		        };
	        /*Chartist.Pie('#chartPreferences', {
	            labels: orderType.orderType,
	            series: orderType.orderCount
	        });*/
	        var chartActivity = Chartist.Bar('#chartPreferences', ord_data, options, responsiveOptions);
	        
	        var dataSales = {
		            labels: totalOrderCount.date,
		            series: [totalOrderCount.count]
		        };
	        
	        var optionsSales = {
		            lineSmooth: false,
		            /*low: 0,
		            high: 800,*/
		            showArea: true,
		            height: "245px",
		            axisX: {
		                showGrid: false,
		            },
		            lineSmooth: Chartist.Interpolation.simple({
		                divisor: 3
		            }),
		            showLine: false,
		            showPoint: false,
		            fullWidth: false
		        };
		
		        var responsiveSales = [
		            ['screen and (max-width: 640px)', {
		                axisX: {
		                    labelInterpolationFnc: function(value) {
		                        return value[0];
		                    }
		                }
		            }]
		        ];
		
		        var chartHours = Chartist.Line('#chartHours', dataSales, optionsSales, responsiveSales);
		        
		        
	}
	
	function show_components(response) {
		var serverDet = response[0];
    	var wfDet = response[1];
    	var ecommDet = response[2];
    	var echannelDet = response[3];
    	var eaiDet = response[4];
    	var bynDet = response[5];
		$('table.servers tbody').html("");
		$('table.wfprocmgr tbody').html("");
		$('table.ecomm tbody').html("");
		$('table.echannel tbody').html("");
		$('table.eai tbody').html("");
		$('table.byn tbody').html("");
    	for (var i=0;i < serverDet.length;i++){
    		var data = serverDet[i];

    		if (data.state == 'Running' || data.state == 'Online'){
        		var serverStat = 'Online';
        		var textColor = 'rgb(34 222 57)';
    		}
    		else{

        		var serverStat = 'Offline';
        		var textColor = 'red';
    		}
    		var row = $('<tr><td>' + data.srvName +
    					'</td><td>' + data.start_time + 
    					'</td><td class="status" style="Color:' + textColor + ';">' + serverStat + 
    					'</td></tr>');
    		$('table.servers tbody').append(row);
    	}
    	for (var i=0;i < wfDet.length;i++){
    		var data = wfDet[i];
    		if (data.cp_disp_run_state == 'Running' || data.cp_disp_run_state == 'Online'){
        		var serverStat = 'Online';
        		var textColor = 'rgb(34 222 57)';
    		}
    		else{

        		var serverStat = 'Offline';
        		var textColor = 'red';
    		}
    		var row = $('<tr><td>' + data.sv_name +
    					'</td><td>' + data.cc_alias + 
    					'</td><td>' + data.cp_num_run_tasks + 
    					'</td><td>' + data.cp_max_tasks +
    					'</td><td>' + data.cp_start_time + 
    					'</td><td class="status" style="Color:' + textColor + ';">' + serverStat + 
    					'</td></tr>');
    		$('table.wfprocmgr tbody').append(row);
    	}
    	for (var i=0;i < ecommDet.length;i++){
    		var data = ecommDet[i];
    		if (data.cp_disp_run_state == 'Running' || data.cp_disp_run_state == 'Online'){
        		var serverStat = 'Online';
        		var textColor = 'rgb(34 222 57)';
    		}
    		else{

        		var serverStat = 'Offline';
        		var textColor = 'red';
    		}
    		var row = $('<tr><td>' + data.sv_name +
					'</td><td>' + data.cc_alias + 
					'</td><td>' + data.cp_num_run_tasks + 
					'</td><td>' + data.cp_max_tasks +
					'</td><td>' + data.cp_start_time + 
					'</td><td class="status" style="Color:' + textColor + ';">' + serverStat +  
					'</td></tr>');
    		$('table.ecomm tbody').append(row);
    	}
    	for (var i=0;i < echannelDet.length;i++){
    		var data = echannelDet[i];
    		if (data.cp_disp_run_state == 'Running' || data.cp_disp_run_state == 'Online'){
        		var serverStat = 'Online';
        		var textColor = 'rgb(34 222 57)';
    		}
    		else{

        		var serverStat = 'Offline';
        		var textColor = 'red';
    		}
    		var row = $('<tr><td>' + data.sv_name +
					'</td><td>' + data.cc_alias + 
					'</td><td>' + data.cp_num_run_tasks + 
					'</td><td>' + data.cp_max_tasks +
					'</td><td>' + data.cp_start_time + 
					'</td><td class="status" style="Color:' + textColor + ';">' + serverStat +  
					'</td></tr>');
    		$('table.echannel tbody').append(row);
    	}
    	for (var i=0;i < eaiDet.length;i++){
    		var data = eaiDet[i];
    		if (data.cp_disp_run_state == 'Running' || data.cp_disp_run_state == 'Online'){
        		var serverStat = 'Online';
        		var textColor = 'rgb(34 222 57)';
    		}
    		else{

        		var serverStat = 'Offline';
        		var textColor = 'red';
    		}
    		var row = $('<tr><td>' + data.sv_name +
					'</td><td>' + data.cc_alias + 
					'</td><td>' + data.cp_num_run_tasks + 
					'</td><td>' + data.cp_max_tasks +
					'</td><td>' + data.cp_start_time + 
					'</td><td class="status" style="Color:' + textColor + ';">' + serverStat + 
					'</td></tr>');
    		$('table.eai tbody').append(row);
    	}
    	for (var i=0;i < bynDet.length;i++){
    		var data = bynDet[i];
    		if (data.cp_disp_run_state == 'Running' || data.cp_disp_run_state == 'Online'){
        		var serverStat = 'Online';
        		var textColor = 'rgb(34 222 57)';
    		}
    		else{

        		var serverStat = 'Offline';
        		var textColor = 'red';
    		}
    		var row = $('<tr><td>' + data.sv_name +
					'</td><td>' + data.cc_alias + 
					'</td><td>' + data.cp_num_run_tasks + 
					'</td><td>' + data.cp_max_tasks +
					'</td><td>' + data.cp_start_time + 
					'</td><td class="status" style="Color:' + textColor + ';">' + serverStat + 
					'</td></tr>');
    		$('table.byn tbody').append(row);
    	}
	}
});