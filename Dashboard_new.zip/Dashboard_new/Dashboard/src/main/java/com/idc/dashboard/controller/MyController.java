package com.idc.dashboard.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MyController {
	
	@GetMapping("/")
	 public String index() {
		System.out.println("First Controller");
        return "dashboard";
    }
	
	@GetMapping("/table")
	public String table() {
		return "table";
	}
	
	@GetMapping("/notifications")
	public String notifications() {
		System.out.println("Notifications");
		return "notifications";
	}
}
