package com.idc.dashboard.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	
	Connection c;
	
	public Connection getConnection() {
		try{
			   String url="jdbc:mysql://localhost:3306/dashboard";  
//			   Class.forName("com.mysql.cj.jdbc.Driver");  
			   c=DriverManager.getConnection(url, "root", "admin246"); 
			   return c; 
			}catch(Exception e){
				e.printStackTrace();
			}
		return c;
	}
	
	public void closeConnection(Connection c) {
		try {
			c.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
