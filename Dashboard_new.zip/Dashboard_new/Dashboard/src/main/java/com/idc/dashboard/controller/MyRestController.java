package com.idc.dashboard.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.idc.dashboard.model.OrderTypeAndCount;
import com.idc.dashboard.model.TotalOrderCount;
import com.idc.dashboard.services.UserService;
import com.idc.dashboard.services.UserServiceImpl;

@RestController
public class MyRestController {

	UserService userService = new UserServiceImpl();

	List<Object> order_stat = new ArrayList<>();

	List<Object> allReport = new ArrayList<Object>();

	OrderTypeAndCount orderTypeAndCount = new OrderTypeAndCount();

	TotalOrderCount totalOrderCount = new TotalOrderCount();

	List<List<Object>> map = new ArrayList<List<Object>>();

	@GetMapping("/api/reports")
	public List<Object> getReports() {
		order_stat = userService.getReports();
		orderTypeAndCount = userService.getCountBasedOnOrderType();
		allReport.add(order_stat);
		allReport.add(orderTypeAndCount);
		totalOrderCount = userService.getTotalOrderCount();
		allReport.add(totalOrderCount);
		System.out.println(order_stat);
		System.out.println(orderTypeAndCount.getOrderType());
		return allReport;
	}

	@GetMapping("/api/comp")
	public List<List<Object>> getCompDetails() {
		map = userService.getServers();
		return map;
	}

//	
//	  @RequestMapping(value = "/download", method = RequestMethod.GET) public
//	  ResponseEntity<Object> downloadFile() throws IOException {
//	  
//	  InputStream in = getClass()
//	  .getResourceAsStream("C:\\Users\\nandan.umashankar\\Desktop\\Telenor Documentation"
//	  ); return IOUtils.toByteArray(in);
//	  
//	  String filename = "/var/tmp/mysql.png"; File file = new File(filename);
//	  InputStreamResource resource = new InputStreamResource(new
//	  FileInputStream(file)); HttpHeaders headers = new HttpHeaders();
//	  
//	  headers.add("Content-Disposition",
//	  String.format("attachment; filename=\"%s\"", file.getName()));
//	  headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
//	  headers.add("Pragma", "no-cache"); headers.add("Expires", "0");
//	  
//	  ResponseEntity<Object> responseEntity =
//	  ResponseEntity.ok().headers(headers).contentLength(file.length()).
//	  contentType( MediaType.parseMediaType("application/txt")).body(resource);
//	  
//	  return responseEntity; }
	 

}
