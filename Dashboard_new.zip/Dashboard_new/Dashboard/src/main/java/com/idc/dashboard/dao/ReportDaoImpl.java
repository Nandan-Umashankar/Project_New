package com.idc.dashboard.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import com.idc.dashboard.model.ComponentDetails;
import com.idc.dashboard.model.OrderTypeAndCount;
import com.idc.dashboard.model.SRM_REQEUST;
import com.idc.dashboard.model.ServerDetails;
import com.idc.dashboard.model.TotalOrderCount;

public class ReportDaoImpl implements ReportDao {
	
	DatabaseConnection db = new DatabaseConnection();
	
	SRM_REQEUST srm = new SRM_REQEUST();
	
	Connection con = db.getConnection();
	
	Statement st;
	
	int escl = 0;
	
	List<List<Object>> result = new ArrayList<List<Object>>();
	
	List<List<Object>> list = new ArrayList<List<Object>>();
	
	HashMap<String, Object> map = new HashMap<String, Object>();
	
	HashMap<String, Object> serversMap = new HashMap<String, Object>();

	@Override
	public List<Object> getReportsAll() {
		// TODO Auto-generated method stub
		ResultSet rs;
		List<Object> data = new ArrayList<Object>();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT COUNT_ACT,COUNT_QUE FROM S_SRM_REQUEST;");
			while (rs.next()) {
			srm.setActive(Integer.parseInt(rs.getString("COUNT_ACT")));
			srm.setQueued(Integer.parseInt(rs.getString("COUNT_QUE")));
			}
			
			rs = st.executeQuery("SELECT pending, pending_asset, open_payment from S_ORDER;");
			rs.next();
			int pending = Integer.parseInt(rs.getString("pending"));
			int pend_ass = Integer.parseInt(rs.getString("pending_asset"));
			int open_pay = Integer.parseInt(rs.getString("open_payment"));
			
			rs = st.executeQuery("SELECT COUNT_REAL AS COUNT FROM S_ESCL_REQ;");
			rs.next();
			escl = Integer.parseInt(rs.getString("COUNT"));
			
			
			data.add(escl);
			data.add(srm.getActive());
			data.add(pending);
			data.add(pend_ass);
			data.add(open_pay);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}

	@Override
	public OrderTypeAndCount getCountBasedOnOrderType() {
		// TODO Auto-generated method stub
		OrderTypeAndCount orderTypeAndCount = new OrderTypeAndCount();
		try {
			List<String> orderType = new ArrayList<String>();
			List<Integer> orderCount = new ArrayList<Integer>();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT ORDER_TYPE, COUNT_ORDER FROM S_ORDER_ITEM;");
			while (rs.next()) {
				orderType.add(rs.getString("ORDER_TYPE"));
				orderCount.add(Integer.parseInt(rs.getString("COUNT_ORDER")));
			}
			orderTypeAndCount.setOrderType(orderType);
			orderTypeAndCount.setOrderCount(orderCount);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return orderTypeAndCount;
	}

	@Override
	public TotalOrderCount getTotalOrderCount() {
		// TODO Auto-generated method stub
		List<String> date = new ArrayList<String>();
		List<Integer> count = new ArrayList<Integer>();
		TotalOrderCount totalOrderCount = new TotalOrderCount();
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT DATE_FORMAT(ORDER_DATE,'%m-%d') AS DAY_COUNT, COUNT FROM ORDER_TRACK ORDER BY DAY_COUNT ASC;");
			while (rs.next()) {
				date.add(rs.getString("DAY_COUNT"));
				count.add(Integer.parseInt(rs.getString("COUNT")));
			}
			totalOrderCount.setDate(date);
			totalOrderCount.setCount(count);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return totalOrderCount;
	}

	@Override
	public List<List<Object>> getServers() {
		// TODO Auto-generated method stub
		
//		File file = new File();
		Path root = Paths.get("C:\\Nandan\\Rajkumar");		
		try {
			Files.find(root, Integer.MAX_VALUE, (path, attrs) -> attrs.isDirectory())
			// for each directory
			.forEach((dir) -> {
			    try {
			        // find all contained files
			        Optional<Path> recentFile = Files.find(dir, 1, 
			                  (path, attrs) -> attrs.isRegularFile())
			                // return the file with the recent last
			                // modification time
			                .max((p1, p2)
			                        -> Long.compare(
			                    p1.toFile().lastModified(),
			                    p2.toFile().lastModified()));
			        // if a file was found
			        if (recentFile.isPresent()) {
			            // print modification time and file name
			        	list = printFileInfo(recentFile.get().toFile());
			        }
			       
			    } catch (IOException ex) {
			        ex.printStackTrace(System.err);
			    }
			});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	private List<List<Object>> printFileInfo(java.io.File file) {
		// TODO Auto-generated method stub
		System.out.printf("  mtime: %td.%<tm.%<tY  %<tH:%<tM:%<tS  file: %s%n",
                new Date(file.lastModified()),
                file.getAbsolutePath()
                
        );
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(file));
			String st; 

			int countArr = 0;
			List<List<String>> allRows = new ArrayList<List<String>>();
			int count = 0;
			List<Object> serverDetails = new ArrayList<Object>();
			List<Object> wfProcMgrDetails = new ArrayList<Object>();
			List<Object> eCommDetails = new ArrayList<Object>();
			List<Object> eChannelDetails = new ArrayList<Object>();
			List<Object> eaiDetails = new ArrayList<Object>();
			List<Object> IDCBYNDetails = new ArrayList<Object>();
			
			boolean wfprocmgr = false;
			boolean ecomm = false;
			boolean echannel = false;
			boolean eai = false;
			boolean byn = false;
			boolean servers = false;
			
			int serverCount = 0;
			int wfCount = 0;
			int eCommCount = 0;
			int echannelCount = 0;
			int eaiCount = 0;
			int bynCount = 0;
			
			  while ((st = br.readLine()) != null) {
//				  System.out.println(st.length());

				  count++;
//				  if((st.trim().indexOf("SIEAPP") == 0) || (st.trim().indexOf("siebelsrv2") == 0))
				  if(count < 23){
				      continue;
				  }
//				  System.out.println("srvrmgr:" + st.contains("srvrmgr"));
				  if(st.contains("------"))
					  continue;
				  if(st.contains("srvrmgr")) {
//					  System.out.println(st.contains("server"));
					  if(st.contains("server")) {
						  servers = true;
					  }
					  if(st.contains("list component wfprocmgr")) {
						  servers = false;
						  wfprocmgr = true;
					  }
					  if(st.contains("list component ecommunicationsobjmgr")) {
						  wfprocmgr = false;
						  ecomm = true;
					  }
					  if(st.contains("list component echannelobjmgr")) {
						  ecomm = false;
						  echannel = true;
					  }
					  if(st.contains("list component eaiobjmgr")) {
						  echannel = false;
						  eai = true;
					  }
					  if(st.contains("list component IDCBYNWF")) {
						  eai = false;
						  byn = true;
					  }
					  continue;
				  }
				  if(st.contains("SBLSRVR_NAME") || st.contains("SV_NAME") || st.contains("SIEAPP") || st.contains("siebelsrv2")) {
					  if((servers == true && st.contains("SBLSRVR_NAME")) || ((wfprocmgr == true || ecomm == true || echannel == true || eai == true || byn == true) && (st.contains("SV_NAME")))) 
						  continue;
					  if((st.contains("SIEAPP") || st.contains("siebelsrv")) && servers == true) {
						  serverCount++;
						  allRows.add(splitLine(st));
					  }
					  if(st.contains("SIEAPP") && wfprocmgr == true) {
						  wfCount++;
						  allRows.add(splitLine(st));
					  }
					  if(st.contains("SIEAPP") && ecomm == true) {
						  eCommCount++;
						  allRows.add(splitLine(st));
					  }
					  if(st.contains("SIEAPP") && echannel == true) {
						  echannelCount++;
						  allRows.add(splitLine(st));
					  }
					  if(st.contains("SIEAPP") && eai == true) {
						  eaiCount++;
						  allRows.add(splitLine(st));
					  }
					  if(st.contains("SIEAPP") && byn == true) {
						  bynCount++;
						  allRows.add(splitLine(st));
					  }
				  }
						  
			  }
			  System.out.println(serverCount + ":" + wfCount + ":" + eCommCount + ":" + echannelCount + ":" + eaiCount + ":" + bynCount + ":");
			  System.out.println(allRows.size());
			  int maxCount =0;
			  for(List<String> ar : allRows) {
				  //set server details with values from file\
				  countArr++;
				  if(countArr <= serverCount) {
					  ServerDetails sd = new ServerDetails();
					  if(ar.size() > maxCount)
						  maxCount = ar.size();
					  for (int i=1;i<=ar.size();i++) {
						  switch (i) {
						case 1:
							sd.setSrvName(ar.get(0));
							break;
						case 2:
							if(ar.size() >= maxCount)
									sd.setState(ar.get(1));
							else
								if(ar.get(1).contains("Handshake")) {
									System.out.println(ar.get(1).contains("Handshake"));
									sd.setState(ar.get(1) + " " + ar.get(2));
								}
							break;	
						case 3:
							if(ar.size() >= maxCount) {
								String dateStr = ar.get(2) + " " + ar.get(3);
								sd.setStart_time(dateStr);
							}
							break;
						default:
							break;
						}
					  }
						serverDetails.add(sd);
				  }
				  //set wfproc details
				  if(countArr > serverCount && countArr <= (serverCount+wfCount)) {
					  ComponentDetails cd = new ComponentDetails();
					  if(ar.size() > maxCount)
						  maxCount = ar.size();
					  for(int i=1;i<=ar.size();i++) {
						  switch (i) {
						  case 1:
							  cd.setSv_name(ar.get(0));
							  break;
						  case 2:
								cd.setCc_alias(ar.get(1));
								break;
						  case 3:
							  if(ar.size() >= maxCount)
								cd.setCp_disp_run_state(ar.get(2));
								break;
						  case 4:
							  if(ar.size() >= maxCount)
								cd.setCp_num_run_tasks(Integer.parseInt(ar.get(3)));
								break;
						  case 5:
							  if(ar.size() >= maxCount)
								cd.setCp_max_tasks(Integer.parseInt(ar.get(4)));
								break;
						  case 6:
							  if(ar.size() >= maxCount) {
								String dateStr = ar.get(5) + " " + ar.get(6);
								cd.setCp_start_time(dateStr);
							  }
								break;
						  default:
							  	break;
						  }
						}
						wfProcMgrDetails.add(cd);
				  }
				//set ecomm details
				  if((countArr > (serverCount+wfCount)) && countArr <= (serverCount+wfCount+eCommCount)) {
					  ComponentDetails cd = new ComponentDetails();
					  if(ar.size() > maxCount)
						  maxCount = ar.size();
					  for(int i=1;i<=ar.size();i++) {
						  switch (i) {
						  case 1:
							  cd.setSv_name(ar.get(0));
							  break;
						  case 2:
								cd.setCc_alias(ar.get(1));
								break;
						  case 3:
							  if(ar.size() >= maxCount)
								cd.setCp_disp_run_state(ar.get(2));
								break;
						  case 4:
							  if(ar.size() >= maxCount)
								cd.setCp_num_run_tasks(Integer.parseInt(ar.get(3)));
								break;
						  case 5:
							  if(ar.size() >= maxCount)
								cd.setCp_max_tasks(Integer.parseInt(ar.get(4)));
								break;
						  case 6:
							  if(ar.size() >= maxCount) {
								String dateStr = ar.get(5) + " " + ar.get(6);
								cd.setCp_start_time(dateStr);
							  }
								break;
						  default:
							  	break;
						  }
						}
						eCommDetails.add(cd);
				  }
				 //set echannel details
				  if(countArr > (serverCount+wfCount+eCommCount) && countArr <= (serverCount+wfCount+eCommCount+echannelCount)) {
					  ComponentDetails cd = new ComponentDetails();
					  if(ar.size() > maxCount)
						  maxCount = ar.size();
					  for(int i=1;i<=ar.size();i++) {
						  switch (i) {
						  case 1:
							  cd.setSv_name(ar.get(0));
							  break;
						  case 2:
								cd.setCc_alias(ar.get(1));
								break;
						  case 3:
							  if(ar.size() >= maxCount)
								cd.setCp_disp_run_state(ar.get(2));
								break;
						  case 4:
							  if(ar.size() >= maxCount)
								cd.setCp_num_run_tasks(Integer.parseInt(ar.get(3)));
								break;
						  case 5:
							  if(ar.size() >= maxCount)
								cd.setCp_max_tasks(Integer.parseInt(ar.get(4)));
								break;
						  case 6:
							  if(ar.size() >= maxCount) {
								String dateStr = ar.get(5) + " " + ar.get(6);
								cd.setCp_start_time(dateStr);
							  }
								break;
						  default:
							  	break;
						  }
						}
						eChannelDetails.add(cd);
						System.out.println(eChannelDetails.size());
				  }
				  //set eai details
				  if(countArr > (serverCount+wfCount+eCommCount+echannelCount) && countArr <= (serverCount+wfCount+eCommCount+echannelCount+eaiCount)) {
					  ComponentDetails cd = new ComponentDetails();
					  if(ar.size() > maxCount)
						  maxCount = ar.size();
					  for(int i=1;i<=ar.size();i++) {
						  switch (i) {
						  case 1:
							  cd.setSv_name(ar.get(0));
							  break;
						  case 2:
								cd.setCc_alias(ar.get(1));
								break;
						  case 3:
							  if(ar.size() >= maxCount)
								cd.setCp_disp_run_state(ar.get(2));
								break;
						  case 4:
							  if(ar.size() >= maxCount)
								cd.setCp_num_run_tasks(Integer.parseInt(ar.get(3)));
								break;
						  case 5:
							  if(ar.size() >= maxCount)
								cd.setCp_max_tasks(Integer.parseInt(ar.get(4)));
								break;
						  case 6:
							  if(ar.size() >= maxCount) {
								String dateStr = ar.get(5) + " " + ar.get(6);
								cd.setCp_start_time(dateStr);
							  }
								break;
						  default:
							  	break;
						  }
						}
						eaiDetails.add(cd);
				  }
				  //set byn details
				  if(countArr > (serverCount+wfCount+eCommCount+echannelCount+eaiCount) && countArr <= (serverCount+wfCount+eCommCount+echannelCount+eaiCount+bynCount)) {
					  ComponentDetails cd = new ComponentDetails();
					  if(ar.size() > maxCount)
						  maxCount = ar.size();
					  for(int i=1;i<=ar.size();i++) {
						  switch (i) {
						  case 1:
							  cd.setSv_name(ar.get(0));
							  break;
						  case 2:
								cd.setCc_alias(ar.get(1));
								break;
						  case 3:
							  if(ar.size() >= maxCount)
								cd.setCp_disp_run_state(ar.get(2));
								break;
						  case 4:
							  if(ar.size() >= maxCount)
								cd.setCp_num_run_tasks(Integer.parseInt(ar.get(3)));
								break;
						  case 5:
							  if(ar.size() >= maxCount)
								cd.setCp_max_tasks(Integer.parseInt(ar.get(4)));
								break;
						  case 6:
							  if(ar.size() >= maxCount) {
								String dateStr = ar.get(5) + " " + ar.get(6);
								cd.setCp_start_time(dateStr);
							  }
								break;
						  default:
							  	break;
						  }
						}
						IDCBYNDetails.add(cd);
				  }
			  }
			  result.add(serverDetails);
			  result.add(wfProcMgrDetails);
			  result.add(eCommDetails);
			  result.add(eChannelDetails);
			  result.add(eaiDetails);
			  result.add(IDCBYNDetails);
			  map.put("servers", serverDetails);	
			  map.put("wfprocmgr", wfProcMgrDetails);
			  map.put("ecomm", eCommDetails);
			  map.put("echannel", eChannelDetails);
			  map.put("eai", eaiDetails);
			  map.put("byn", IDCBYNDetails);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result; 
	}
	
	public List<String> splitLine(String st){
		List<String> row = new ArrayList<String>();
		  String[] words = st.split(" "); 
		  for(String sx : words) {
			  if(sx == null || sx == " " || sx.isEmpty() == true)
				  continue;
			  row.add(sx);
		  }
		  while (row.contains(null)) {
			  row.remove(null);
		  }	
		  return row;
	}
}
