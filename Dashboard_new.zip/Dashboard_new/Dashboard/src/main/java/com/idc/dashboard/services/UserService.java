package com.idc.dashboard.services;

import java.util.List;

import com.idc.dashboard.model.OrderTypeAndCount;
import com.idc.dashboard.model.TotalOrderCount;


public interface UserService {
	
	List<Object> getReports();

	OrderTypeAndCount getCountBasedOnOrderType();

	TotalOrderCount getTotalOrderCount();
	
	List<List<Object>> getServers();
		
}
