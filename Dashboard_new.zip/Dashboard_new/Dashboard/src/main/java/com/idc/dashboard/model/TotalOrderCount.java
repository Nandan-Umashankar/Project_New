package com.idc.dashboard.model;

import java.util.List;

public class TotalOrderCount {

	private List<String> date;
	private List<Integer> count;
	public List<String> getDate() {
		return date;
	}
	public void setDate(List<String> date2) {
		this.date = date2;
	}
	public List<Integer> getCount() {
		return count;
	}
	public void setCount(List<Integer> count) {
		this.count = count;
	}
}
