package com.idc.dashboard.model;

public class ComponentDetails {
	private String sv_name;
	private String cc_alias;
	private String cp_disp_run_state;
	private int cp_num_run_tasks;
	private int cp_max_tasks;
	private String cp_start_time;
	public String getSv_name() {
		return sv_name;
	}
	public void setSv_name(String sv_name) {
		this.sv_name = sv_name;
	}
	public String getCc_alias() {
		return cc_alias;
	}
	public void setCc_alias(String cc_alias) {
		this.cc_alias = cc_alias;
	}
	public String getCp_disp_run_state() {
		return cp_disp_run_state;
	}
	public void setCp_disp_run_state(String cp_disp_run_state) {
		this.cp_disp_run_state = cp_disp_run_state;
	}
	public int getCp_num_run_tasks() {
		return cp_num_run_tasks;
	}
	public void setCp_num_run_tasks(int cp_num_run_tasks) {
		this.cp_num_run_tasks = cp_num_run_tasks;
	}
	public int getCp_max_tasks() {
		return cp_max_tasks;
	}
	public void setCp_max_tasks(int cp_max_tasks) {
		this.cp_max_tasks = cp_max_tasks;
	}
	public String getCp_start_time() {
		return cp_start_time;
	}
	public void setCp_start_time(String cp_start_time) {
		this.cp_start_time = cp_start_time;
	}
}
