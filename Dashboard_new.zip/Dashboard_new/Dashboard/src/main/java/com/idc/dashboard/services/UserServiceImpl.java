package com.idc.dashboard.services;

import java.util.ArrayList;
import java.util.List;

import com.idc.dashboard.dao.ReportDao;
import com.idc.dashboard.dao.ReportDaoImpl;
import com.idc.dashboard.model.OrderTypeAndCount;
import com.idc.dashboard.model.TotalOrderCount;

public class UserServiceImpl implements UserService {

	List<Object> list = new ArrayList<Object>();
	
	ReportDao reportDao = new ReportDaoImpl();
	
	@Override
	public List<Object> getReports() {
		
		list = reportDao.getReportsAll();
		return list;
		// TODO Auto-generated method stub
	}

	@Override
	public OrderTypeAndCount getCountBasedOnOrderType() {
		// TODO Auto-generated method stub
		OrderTypeAndCount orderTypeCount = new OrderTypeAndCount();
		orderTypeCount = reportDao.getCountBasedOnOrderType();
		return orderTypeCount;
	}

	@Override
	public TotalOrderCount getTotalOrderCount() {
		// TODO Auto-generated method stub
		TotalOrderCount totalOrderCount = new TotalOrderCount();
		totalOrderCount = reportDao.getTotalOrderCount();
		return totalOrderCount;
	}

	@Override
	public List<List<Object>> getServers() {
		// TODO Auto-generated method stub
		List<List<Object>> map = new ArrayList<List<Object>>();
		map = reportDao.getServers();
		return map;
	}

}
